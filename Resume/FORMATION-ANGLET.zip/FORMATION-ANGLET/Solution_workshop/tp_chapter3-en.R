#################################################
#          Solutions to Worksheet from Chap. 3  #
#               Study of Body Mass Index        #
#################################################

# 3.1-
Individuals <- c("Edward","Cynthia","Eugene","Elizabeth",
                 "Patrick","John","Albert","Lawrence",
                 "Joseph","Leo")
Weight <- c(16,14,13.5,15.4,16.5,16,17,14.8,17,16.7)
Height <- c(100,97,95.5,101,100,98.5,103,98,101.5,100)
Gender <- c("F","F","M","F","M","M","M","M","M","M")
# 3.2-
mean(Weight) # result : [1] 15.69
mean(Height) # result : [1] 99.45
# 3.3-
BMI <- Weight/(Height/100)^2
BMI   # Outputs the results
# 3.4-
myTable <- data.frame(Individuals,Weight,Height,Gender,BMI)
myTable   # Outputs the results
# 3.5-
help(plot)
# 3.6-
plot(Height,Weight,main="Scatter plot of Weight as a
          function of Height")
