#### How to read data

mydata <- read.csv(file="~/Dropbox/R-book/Day1/Data/Multiple_Regression_Data.csv",header=TRUE)
dim(mydata)
head(mydata)


####
getwd()
setwd("~/Dropbox/R-book/Day1/Data/")
newdata <- read.table(file="Intima_Media_Thickness.txt",header = T,dec=",",sep=" ")
head(newdata)
str(newdata)
mean(AGE)
mean(newdata$AGE)
mean(newdata[,"AGE"])
mean(newdata[,2])

attach(newdata)
mean(AGE)
hist(height)
detach(newdata)
head(newdata)
AGE

### read data from internet 
temp <- read.table("http://www.biostatisticien.eu/springeR/temperature.dat")
head(temp)


### read data by using copy/paste

data.excel <- read.table(file("clipboard"),dec=".",sep=" ",header=TRUE)
data.excel <- read.table(file("clipboard"),dec=".",sep="\t",header = TRUE) 
